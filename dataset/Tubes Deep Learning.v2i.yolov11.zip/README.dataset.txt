# Tubes Deep Learning > 2025-01-08 5:29pm
https://universe.roboflow.com/tes-rwkwj/tubes-deep-learning

Provided by a Roboflow user
License: CC BY 4.0

